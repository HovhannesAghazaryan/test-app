<?php
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past
?><!DOCTYPE html>
<html>
  <head>
    <title>Welcome to AWS Technical Essentials v4.1</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>    
       .table.table-bordered {
           margin-bottom: 0px; 
       }
       .navbar.navbar-default{
           margin-bottom: 0px;
       }
       .jumbotron {
          margin: 0px;
          background-color: #FFF;
       }
       .hideborder .navbar.navbar-default{
          background-color: #FFF;
          border-color: #FFF;
       }
       .container{
          padding: 10px;
       }
       .nav.navbar-nav{
          display: none;
       }
    </style>
  </head>

  <body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <nav class="navbar navbar-default">
                 <div class="hideborder">
                      <?php include('menu.php'); ?>
                 </div>
                 <div class="jumbotron" style="padding:0px;">
                      <div style="padding:10px;">
                             <?php include("get-index-meta-data.php"); ?>

                             <?php include('get-cpu-load.php'); ?>
                      </div>
                      <div style="padding-top: 65%; background-repeat: no-repeat; background-size: 100%; background-image: url('https://hovhannesbucket.s3.amazonaws.com/background.png')">
                        
                     </div>
                 </div>

                 <div style="padding:10px;">
                     <table class="table table-bordered">
                          <tbody>
                              <tr>
                                  <th>Terraria</th>
                                  <th>Unreal Tournament</th>
                              </tr>
                              <tr>
                                  <th>54.174.186.121:7777</th>
                                  <th>Not available</th> 
                              </tr>
                         </tbody>
                     </table>
                </div>
            </nav>
            
        </div>
    </div>


    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>

  </body>
</html>